CREATE TABLE IF NOT EXISTS songify."bonus_songs" (
    "id" INT,
    "title" TEXT,
    "artist" TEXT,
    "year" TEXT
);
INSERT INTO songify."bonus_songs" VALUES
    (2229,'Can''t Stop the Feeling','Justin Timberlake',2016),
    (2230,'Send My Love (To Your New Lover)','Adele',2016),
    (2231,'Scars to Your Beautiful','Alessia Cara',2016),
    (2232,'Formation','Beyonce',2016);
